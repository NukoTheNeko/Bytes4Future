import { TimerMain } from './timer_components/TimerMain';

function App() {
  return (
    <TimerMain />
  );
}

export default App;
